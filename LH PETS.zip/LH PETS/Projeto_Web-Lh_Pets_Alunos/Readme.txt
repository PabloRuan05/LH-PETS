Não consegui conectar o banco de dados ao meu código, eu estava usando a autenticação do windows, pesquisei mas não consegui encontrar como conectar.
o perfil do SQL Server: id= sa, senha: 12345, deu erro por causa de umas permissões que não estavam permitindo a execução do arquivo vendas.sql.
testei e deu tudo certo só não exibiu os dados cadastrados. 